/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labtask3;
import java.util.Scanner;


/**
 *
 * @author hp
 */
public class LabTask3 {

    public static void main(String[] args) {
        int a,b;
        System.out.print("Enter first integer ");
        Scanner sc=new Scanner(System.in);
        a=sc.nextInt();
        System.out.print("Entered Second Integer ");
        b=sc.nextInt();
        System.out.println("Value of First int is "+a);
        System.out.println("Value of second int is "+b);
        int sum=a+b;
        System.out.println("Sum of number is "+sum);
        int differ=a-b;
        System.out.println("Difference is "+differ);
        int pro=a*b;
        System.out.println("Product of number is "+pro);
        int divide=a/b;
        System.out.println("Division of number is "+divide);
        int remainder=a%b;
        System.out.println("Remainder of number is "+remainder);
    }
}
