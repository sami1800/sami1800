/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labtask10;

/**
 *
 * @author hp
 */
public class LabTask10 {

    public static void main(String[] args) {
        int term=20;
        int a=0;
        int b=1;
        int c;
        System.out.println("Fabonacci series upto 20th term ");
        for(int i=1;i<=term;i++){
            System.out.println("("+i+") "+a+" ");
            c=a+b;
            a=b;
            b=c;
            
        
        }
    }
}
