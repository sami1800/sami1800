/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labtask7;
import java.util.Scanner;
/**
 *
 * @author hp
 */
public class LabTask7 {

    public static void main(String[] args) {
        int value;
        System.out.println("Enter any value ");
        Scanner sc=new Scanner(System.in);
        value=sc.nextInt();
        System.out.println("Enter value is "+value);
        int m=value/2;
        int flag=0;
        for(int i=2;i<=m;i++){
            if(value%i==0){
                System.out.println("Number is not prime");
                flag=1;
                break;
            }
        }
        if(flag==0){
            System.out.println("Number is prime ");
        }
    }
}
