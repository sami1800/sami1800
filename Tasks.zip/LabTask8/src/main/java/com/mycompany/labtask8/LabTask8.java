/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labtask8;
import java.util.Scanner;

/**
 *
 * @author hp
 */
public class LabTask8 {

    public static void main(String[] args) {
        String first;
        System.out.println("Enter any string ");
        Scanner sc=new Scanner(System.in);
        first=sc.nextLine();
       String second;
       System.out.println("Enter second string ");
       second=sc.nextLine(); 
        int result=first.compareToIgnoreCase(second);
        if(result==0){
            System.out.println("String are same ");
        }else{
            System.out.println("String are not same");
        }
        
        
        
    }
}
