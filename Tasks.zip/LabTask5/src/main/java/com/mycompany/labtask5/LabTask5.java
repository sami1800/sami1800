/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labtask5;
import java.util.Scanner;


/**
 *
 * @author hp
 */
public class LabTask5 {

    public static void main(String[] args) {
        int a;
        System.out.println("Enter any int ");
        Scanner sc=new Scanner(System.in);
        a=sc.nextInt();
        float b;
        System.out.println("Enter any floating number ");
        b=sc.nextFloat();
        int c=(int) b;
        if(a==c){
            System.out.println("Numbers are equal");
        
        }else{
            System.out.println("Numbers are not equal");
        }
        
        
        
    }
}
