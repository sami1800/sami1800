/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labtask9;
import java.util.Scanner;

/**
 *
 * @author hp
 */
public class LabTask9 {

    public static void main(String[] args) {
       float radius;
        System.out.println("Enter radius ");
       Scanner sc=new Scanner(System.in);
       radius=sc.nextFloat();
       float dia=2*radius;
        System.out.println("Diameter of circle is "+dia);
        float pi=3.14f;
        float circum=2*pi*radius;
        System.out.println("Circumference of circle is "+circum);
        float area=pi*(radius*radius);
        System.out.println("Area of circle is "+area);
        
        
        
        
       
    }
}
