/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labtask1;
import java.util.Scanner;

/**
 *
 * @author hp
 */
public class LabTask1 {

    public static void main(String[] args) {
//        inputs from user
        int a;
        System.out.print("Enter any integer : ");
        Scanner sc=new Scanner(System.in);
        a=sc.nextInt();
        float b;
        System.out.print("Enter any floating value ");
        b=sc.nextFloat();
        char ch;
        System.out.print("Enter any Character ");
        ch=sc.next().charAt(0);
        String c;
        System.out.print("Enter any string ");
        c=sc.nextLine();
        boolean type;
        System.out.print("Enter True or false ");
        type = sc.nextBoolean();
//        output of following
         System.out.println("Value  of int is "+a);
         System.out.println("Value of float is "+b);
         System.out.println("Valur of character is "+ch);
         System.out.println("Value of string is "+c);
         System.out.println("Value of bool is "+type);

        
        
        
        
        
        
        
    }
}
