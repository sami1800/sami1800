/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labtask4;
import java.util.Scanner;


/**
 *
 * @author hp
 */
public class LabTask4 {

    public static void main(String[] args) {
       int input;
        System.out.println("Enter any value for integer ");
        Scanner sc=new Scanner(System.in);
        input=sc.nextInt();
        System.out.println("Entered value is "+input);
        System.out.println("Table of "+input);
        for(int i=0;i<=10;i++){
            System.out.println(input+" x "+i+" = "+input*i);
        }
        
    }
}
