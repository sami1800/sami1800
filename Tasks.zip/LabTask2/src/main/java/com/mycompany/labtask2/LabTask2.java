/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labtask2;
import java.util.Scanner;

/**
 *
 * @author hp
 */
public class LabTask2 {

    public static void main(String[] args) {
        System.out.print("Enter any string ");
        String value;
        Scanner sc=new Scanner(System.in);
        value=sc.nextLine();
        String second;
        System.out.println("Enter another string ");
        second=sc.nextLine();
        System.out.println("You entered following string "+value);
        System.out.println("Second string is "+second);
        int l=value.length();
        System.out.println("Length of string is "+l);
        String upper=value.toUpperCase();
        System.out.println("Converted string is "+upper);
        String lower=value.toLowerCase();
        System.out.println("Converted String is "+lower);
        String trim=value.trim();
        System.out.println("Converted string is "+trim);
        char a=value.charAt(0);
        System.out.println("Required Charcter is "+a);
        int compare=value.compareToIgnoreCase(second);
        System.out.println("Result is "+compare);
        boolean check=value.equals(second);
        System.out.println("Result is "+check);
        
       
        
        
        
        
        
        
  
        
        
    }
}
